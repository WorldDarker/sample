const express = require('express');
const app = express();
const port = 3000; // You can change this port if needed

// Serve static files (CSS, images, etc.)
app.use(express.static('public'));

// Body parser middleware
app.use(express.urlencoded({ extended: true }));

// Handle signup form submission
app.post('/signup/1', (req, res) => {
  // Process the form data (you can save it to a database)
  const { name, email, mobile, gender, location } = req.body;

  // For simplicity, just log the form data for now
  console.log('Form Data:', { name, email, mobile, gender, location });

  // Redirect to the dance.html page
  res.redirect('/dance.html');
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
